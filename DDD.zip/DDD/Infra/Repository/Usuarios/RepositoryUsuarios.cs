﻿using Domain.Entities;
using Domain.Interfaces.Usuarios;
using Infra.Config;
using Infra.Repository.Generic;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace Infra.Repository.Usuarios
{
    public class RepositoryUsuarios : RepositoryGeneric<Usuario>, InterfaceUsuario
    {

        private readonly DbContextOptionsBuilder<ContextBase> _OptionsBuider;

        public RepositoryUsuarios()
        {
            _OptionsBuider = new DbContextOptionsBuilder<ContextBase>();
        }


        public void Adicionar(Usuario Entity)
        {
            using (var banco = new ContextBase(_OptionsBuider.Options))
            {
                var param = new SqlParameter("@NomeUsuario", Entity.NomeUsuario);
                banco.Database.ExecuteSqlCommand("SalvarUsuario @NomeUsuario", param);
                banco.SaveChanges();
            }
        }

        public void Atualizar(Usuario Entity)
        {
            using (var banco = new ContextBase(_OptionsBuider.Options))
            {
                var param = new SqlParameter("@NomeUsuario", Entity.NomeUsuario);
                var param2 = new SqlParameter("@Id", Entity.Id);

                banco.Database.ExecuteSqlCommand("AtualizarUsuario @NomeUsuario, @Id", param, param2);
                banco.SaveChanges();
            }
        }

        public void Excluir(Usuario Entity)
        {
            using (var banco = new ContextBase(_OptionsBuider.Options))
            {
                var param = new SqlParameter("@Id", Entity.Id);
                banco.Database.ExecuteSqlCommand("ExcluirUsuario @Id", param);
                banco.SaveChanges();
            }
        }

        public List<Usuario> Listar()
        {
            using (var banco = new ContextBase(_OptionsBuider.Options))
            {
                return banco.Usuario.FromSql("ListarTodos").ToList();
            }
        }

        public Usuario ObterPorId(int Id)
        {
            using (var banco = new ContextBase(_OptionsBuider.Options))
            {
                var param = new SqlParameter("@Id", Id);
                return banco.Usuario.FromSql("ObterPorId @Id", param).FirstOrDefault();
            }
        }
    }
}
