﻿using Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.Validations
{
    public class ValidacoesUsuario
    {


        public bool ValidarNomeDoUsuario(Usuario usuario)
        {
            if (string.IsNullOrWhiteSpace(usuario.NomeUsuario))
                return false;
            else
            {
                return true;
            }
        }

    }
}
