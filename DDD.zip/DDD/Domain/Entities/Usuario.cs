﻿using Domain.Validations;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Domain.Entities
{
    [Table("Usuario")]
    public class Usuario : ValidacoesUsuario
    {
        [Column("Id")]
        [Display(Description = "Código")]
        public int Id { get; set; }

        [Column("NomeUsuario")]
        [Display(Description = "Nome do usuário")]
        public string NomeUsuario { get; set; }


      

    }
}
