﻿using Domain.Entities;
using Domain.Interfaces.Generic;
using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.Interfaces.Usuarios
{
    public interface InterfaceUsuario : InterfaceGeneric<Usuario>
    {
        void Adicionar(Usuario Entity);
        void Atualizar(Usuario Entity);
        void Excluir(Usuario Entity);
        Usuario ObterPorId(int Id);
        List<Usuario> Listar();
    }
}
