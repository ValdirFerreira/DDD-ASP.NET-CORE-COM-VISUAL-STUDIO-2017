﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Application.Interfaces;
using Domain.Entities;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DDD_WEB_CORE.Controllers
{
    public class UsuariosController : Controller
    {

        private readonly IAppUsuario AppUsuario;

        public UsuariosController(IAppUsuario _AppUsuario)
        {
            AppUsuario = _AppUsuario;
        }


        // GET: Usuarios
        public ActionResult Index()
        {
            //return View(AppUsuario.List());
            return View(AppUsuario.Listar());
        }

        // GET: Usuarios/Details/5
        public ActionResult Details(int id)
        {

            //return View(AppUsuario.GetEntity(id));

            return View(AppUsuario.ObterPorId(id));

        }

        // GET: Usuarios/Create
        public ActionResult Create()
        {
            return View(new Usuario());
        }

        // POST: Usuarios/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Usuario Usuario)
        {
            try
            {
                //  AppUsuario.Add(Usuario);

                if (Usuario.ValidarNomeDoUsuario(Usuario))
                    AppUsuario.Adicionar(Usuario);

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: Usuarios/Edit/5
        public ActionResult Edit(int id)
        {
            //return View(AppUsuario.GetEntity(id));

            return View(AppUsuario.ObterPorId(id));
        }

        // POST: Usuarios/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, Usuario Usuario)
        {
            try
            {
                // AppUsuario.Update(Usuario);
                AppUsuario.Adicionar(Usuario);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: Usuarios/Delete/5
        public ActionResult Delete(int id)
        {
            //return View(AppUsuario.GetEntity(id));

            return View(AppUsuario.ObterPorId(id));
        }

        // POST: Usuarios/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, Usuario Usuario)
        {
            try
            {
                //  AppUsuario.Delete(Usuario);

                AppUsuario.Excluir(Usuario);

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}