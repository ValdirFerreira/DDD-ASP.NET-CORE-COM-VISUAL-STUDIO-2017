﻿using Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Interfaces
{
    public interface IAppUsuario : IAppGeneric<Usuario>
    {
        void Adicionar(Usuario Entity);
        void Atualizar(Usuario Entity);
        void Excluir(Usuario Entity);
        Usuario ObterPorId(int Id);
        List<Usuario> Listar();
    }
}
