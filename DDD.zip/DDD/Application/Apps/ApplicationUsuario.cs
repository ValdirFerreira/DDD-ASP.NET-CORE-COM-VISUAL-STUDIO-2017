﻿using Application.Interfaces;
using Domain.Entities;
using Domain.Interfaces.Usuarios;
using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Apps
{
    public class ApplicationUsuario : IAppUsuario
    {

        InterfaceUsuario _InterfaceUsuario;

        public ApplicationUsuario(InterfaceUsuario InterfaceUsuario)
        {
            _InterfaceUsuario = InterfaceUsuario;
        }

        public void Adicionar(Usuario Entity)
        {
            _InterfaceUsuario.Adicionar(Entity);
        }

        public void Atualizar(Usuario Entity)
        {
            _InterfaceUsuario.Atualizar(Entity);
        }

        public void Excluir(Usuario Entity)
        {
            _InterfaceUsuario.Excluir(Entity);
        }

        public List<Usuario> Listar()
        {
            return _InterfaceUsuario.Listar();
        }

        public Usuario ObterPorId(int Id)
        {
            return _InterfaceUsuario.ObterPorId(Id);
        }

        #region metodos Entity

        public void Add(Usuario Entity)
        {
            _InterfaceUsuario.Add(Entity);
        }



        public void Delete(Usuario Entity)
        {
            _InterfaceUsuario.Delete(Entity);
        }



        public Usuario GetEntity(int Id)
        {
            return _InterfaceUsuario.GetEntity(Id);
        }

        public List<Usuario> List()
        {
            return _InterfaceUsuario.List();
        }



        public void Update(Usuario Entity)
        {
            _InterfaceUsuario.Update(Entity);
        }
        #endregion
    }
}
